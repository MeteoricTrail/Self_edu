import axios from 'axios';

// OpenAI API 配置
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_API_URL = 'https://api.openai.com/v1/engines/davinci-codex/completions';

// Lambda处理器
export const handler = async (event) => {
    const query = event.queryStringParameters?.query || '';

    const prompt = `Given the following names and their translations:\nDavid Smith 大卫 斯密斯,\nYueling Wang 月林张,\nHuawen Wu 华文吴,\nAnnie Lee 李安妮,\n\nFind the best match for the input: "${query}"`;

    try {
        const response = await axios.post(OPENAI_API_URL, {
            prompt: prompt,
            max_tokens: 100
        }, {
            headers: {
                'Authorization': `Bearer ${OPENAI_API_KEY}`
            }
        });

        const match = response.data.choices[0].text.trim();

        return {
            statusCode: 200,
            body: JSON.stringify({ match })
        };
    } catch (error) {
        console.error('Error calling OpenAI API:', error);
        return {
            statusCode: 500,
            body: 'Error processing your request'
        };
    }
};
